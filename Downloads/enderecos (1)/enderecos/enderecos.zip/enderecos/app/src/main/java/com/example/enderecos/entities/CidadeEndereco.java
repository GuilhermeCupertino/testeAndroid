package com.example.enderecos.entities;

public class CidadeEndereco {

    public int enderecoID;
    public String descricaoEnd;
    public String nomeCidade;

    public int getEnderecoID() { return enderecoID;    }
    @Override
    public String toString() {
        return this.enderecoID + ": " + descricaoEnd
                + " Cidade: "+nomeCidade ;
    }

}
