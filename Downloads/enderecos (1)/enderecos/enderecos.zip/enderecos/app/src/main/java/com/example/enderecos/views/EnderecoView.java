package com.example.enderecos.views;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.enderecos.R;
import com.example.enderecos.database.LocalDatabase;
import com.example.enderecos.databinding.ActivityEnderecoViewBinding;
import com.example.enderecos.entities.Cidade;
import com.example.enderecos.entities.Endereco;

import java.util.List;

public class EnderecoView extends AppCompatActivity {

    private ActivityEnderecoViewBinding binding;
    private LocalDatabase db;
    private int dbEnderecoID;
    private Endereco dbEndereco;
    private List<Cidade> cidades;
    private Spinner spnCidades;
    private ArrayAdapter<Cidade> cidadesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityEnderecoViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        db = LocalDatabase.getDatabase(getApplicationContext());

        spnCidades = binding.spnCidades;
        dbEnderecoID = getIntent().getIntExtra(
                "ENDEREÇO_SELECIONADO_ID", -1);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(dbEnderecoID >= 0){
            preencheEndereco();
        } else {
            binding.btnExcluirModelo.setVisibility(View.GONE);
        }
        preencheCidades();
    }

    private void preencheEndereco() {
        dbEndereco = db.enderecoModel().getEnd(dbEnderecoID);
        binding.edtDescricao.setText(dbEndereco.getDescricao());
    }

    private void preencheCidades() {
        cidades = db.cidadeModel().getAll();
        cidadesAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, cidades);
        spnCidades.setAdapter(cidadesAdapter);
        if(dbEndereco!= null) {
            spnCidades.setSelection(dbEndereco.getCidadeID() - 1);
        }
    }

    public void salvarEndereco(View view) {
        String descricao = binding.edtDescricao.getText().toString();
        String novaCidade = "";

        if(spnCidades.getSelectedItem() != null){
            novaCidade = spnCidades.getSelectedItem().toString();
        }
        if(descricao.equals("")){
            Toast.makeText(this, "A descrição é obrigatória", Toast.LENGTH_SHORT).show();
            return;
        }
        if(novaCidade.equals("")) {
            Toast.makeText(this, "Entre com uma Cidade.", Toast.LENGTH_SHORT).show();
            return;
        }

        Endereco novoEndereco = new Endereco();
        novoEndereco.setDescricao(descricao);
        novoEndereco.setCidadeID(cidades.get(
                spnCidades.getSelectedItemPosition()).getCidadeID());
        if(dbEndereco != null){
            novoEndereco.setEnderecoID(dbEnderecoID);
            db.enderecoModel().update(novoEndereco);
            Toast.makeText(this, "Endereço atualizado com sucesso.",
                    Toast.LENGTH_SHORT).show();
        } else {
            db.enderecoModel().insertAll(novoEndereco);
            Toast.makeText(this, "Endereço cadastrado com sucesso.",
                    Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    public void excluirEndereco(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Exclusão de Endereço")
                .setMessage("Deseja excluir esse endereço?")
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        excluir();
                    }
                })
                .setNegativeButton("Não", null)
                .show();
    }

    public void excluir() {
        db.enderecoModel().delete(dbEndereco);
        Toast.makeText(this, "Endereço excluído com sucesso.", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void voltar(View view) {
        finish();
    }
}