package com.example.enderecos.views;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.enderecos.R;
import com.example.enderecos.database.LocalDatabase;
import com.example.enderecos.databinding.ActivityEnderecoListBinding;
import com.example.enderecos.entities.CidadeEndereco;

import java.util.List;

public class EnderecoList extends AppCompatActivity {

    private ActivityEnderecoListBinding binding;
    private LocalDatabase db;
    private List<CidadeEndereco> cidEnd;
    private ListView listViewEndereco;
    private Intent edtIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityEnderecoListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = LocalDatabase.getDatabase(getApplicationContext());
        listViewEndereco = binding.listEndereco;

        binding.btnHomeEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        binding.btnAddEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EnderecoList.this, EnderecoView.class));
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        edtIntent = new Intent(this, EnderecoView.class);
        preencheEnderecos();
    }

    private void preencheEnderecos() {
        cidEnd = db.cidadeEnderecoModel().getAllCidEnd();
        ArrayAdapter<CidadeEndereco> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, cidEnd);
        listViewEndereco.setAdapter(adapter);

        listViewEndereco.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapter, View view,
                                    int position, long id){
                CidadeEndereco endSelecionado = cidEnd.get(position);
                edtIntent.putExtra("ENDERECO_SELECIONADO_ID",
                        endSelecionado.getEnderecoID());
                startActivity(edtIntent);
            }
        });
    }
}